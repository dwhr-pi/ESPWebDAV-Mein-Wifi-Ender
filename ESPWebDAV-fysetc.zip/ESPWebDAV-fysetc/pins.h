#ifndef _SD_H_
#define _SD_H_

#define SD_CS		4
#define MISO_PIN		12
#define MOSI_PIN		13
#define SCLK_PIN		14
#define CS_SENSE	5

#endif